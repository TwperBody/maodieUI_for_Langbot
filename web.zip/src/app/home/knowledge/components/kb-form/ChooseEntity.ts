export interface IEmbeddingModelEntity {
  label: string;
  value: string;
}

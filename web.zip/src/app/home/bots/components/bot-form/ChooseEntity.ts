export interface IChooseAdapterEntity {
  label: string;
  value: string;
}

export interface IPipelineEntity {
  label: string;
  value: string;
}

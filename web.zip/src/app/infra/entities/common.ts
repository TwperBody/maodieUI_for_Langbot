export interface I18nLabel {
  en_US: string;
  zh_Hans: string;
  ja_JP?: string;
}
